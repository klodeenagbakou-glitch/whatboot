# WhaBoost — Backend

API Node.js/Express connectée à Supabase, WhatsApp Cloud API et Stripe.

## Déploiement sur Render (déjà connecté à ton compte)

Je ne peux pas pousser du code vers un dépôt Git depuis mon environnement.
Il te reste **une seule étape manuelle** :

1. Crée un dépôt GitHub (vide) — ex. `whaboost-backend`.
2. Pousse ce dossier dedans :
   ```bash
   cd whaboost-backend
   git init
   git add .
   git commit -m "Backend initial WhaBoost"
   git branch -M main
   git remote add origin https://github.com/<ton-compte>/whaboost-backend.git
   git push -u origin main
   ```
3. Dis-moi l'URL du dépôt (ou connecte-le toi-même dans le tableau de bord Render) —
   je créerai le service web sur ton workspace Render "Whaboot" avec :
   - Runtime : Node
   - Build command : `npm install`
   - Start command : `npm start`
4. Variables d'environnement à renseigner sur Render (voir `.env.example`) :
   - `SUPABASE_URL` et `SUPABASE_ANON_KEY` (déjà fournis dans `.env.example`, projet Supabase "WhatBoost")
   - `SUPABASE_SERVICE_ROLE_KEY` — à copier depuis Supabase > Project Settings > API (clé secrète, jamais dans le frontend)
   - `WHATSAPP_VERIFY_TOKEN`, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID` — une fois l'accès Meta obtenu
   - `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` — une fois le compte Stripe configuré
   - `FRONTEND_ORIGIN` — l'URL de la vitrine/dashboard une fois déployée

## Développement local

```bash
cp .env.example .env
npm install
npm run dev
```

## Endpoints principaux

| Méthode | Route | Description |
|---|---|---|
| GET | `/health` | vérification que le service tourne |
| GET/POST/PATCH/DELETE | `/api/contacts` | gestion des contacts |
| POST | `/api/contacts/import` | import en masse (Excel/CSV) |
| GET | `/api/conversations` | boîte de réception |
| GET/POST | `/api/conversations/:id/messages` | historique + envoi de message |
| GET/POST | `/api/campaigns` | campagnes marketing |
| POST | `/api/campaigns/:id/send` | déclenche l'envoi à tout le segment |
| GET/PATCH | `/api/profile` | profil de l'entreprise |
| GET/POST | `/webhooks/whatsapp` | vérification + réception WhatsApp |
| POST | `/webhooks/stripe` | paiements et abonnements |

Toutes les routes `/api/*` attendent un header `Authorization: Bearer <access_token_supabase>`
récupéré depuis le frontend après connexion (`supabase.auth.getSession()`).
