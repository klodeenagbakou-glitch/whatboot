import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { sendWhatsAppMessage } from '../lib/whatsapp.js';

const router = Router();
router.use(requireAuth);

// GET /api/conversations?status=open
router.get('/', async (req, res) => {
  const { status } = req.query;
  let query = req.supabase
    .from('conversations')
    .select('*, contacts(full_name, phone_number)')
    .order('last_message_at', { ascending: false });
  if (status) query = query.eq('status', status);

  const { data, error } = await query;
  if (error) return res.status(400).json({ error: error.message });
  res.json({ conversations: data });
});

// GET /api/conversations/:id/messages
router.get('/:id/messages', async (req, res) => {
  const { data, error } = await req.supabase
    .from('messages')
    .select('*')
    .eq('conversation_id', req.params.id)
    .order('created_at', { ascending: true });
  if (error) return res.status(400).json({ error: error.message });
  res.json({ messages: data });
});

// POST /api/conversations/:id/messages   { content }
// Envoie un message sortant : l'enregistre en base puis le pousse sur WhatsApp.
router.post('/:id/messages', async (req, res) => {
  const { content } = req.body;
  if (!content) return res.status(400).json({ error: 'content est requis.' });

  const { data: conversation, error: convError } = await req.supabase
    .from('conversations')
    .select('*, contacts(phone_number)')
    .eq('id', req.params.id)
    .single();
  if (convError || !conversation) return res.status(404).json({ error: 'Conversation introuvable.' });

  const { data: message, error } = await req.supabase
    .from('messages')
    .insert({
      conversation_id: req.params.id,
      direction: 'outbound',
      sender_type: 'agent',
      content,
      status: 'queued',
    })
    .select()
    .single();
  if (error) return res.status(400).json({ error: error.message });

  try {
    const { data: connection } = await req.supabase
      .from('whatsapp_connections')
      .select('phone_number_id')
      .maybeSingle();
    if (!connection) throw new Error("Aucun numéro WhatsApp connecté — allez dans Paramètres > WhatsApp.");

    const waResponse = await sendWhatsAppMessage(connection.phone_number_id, conversation.contacts.phone_number, content);
    await req.supabase
      .from('messages')
      .update({ status: 'sent', whatsapp_message_id: waResponse?.messages?.[0]?.id })
      .eq('id', message.id);
  } catch (err) {
    await req.supabase.from('messages').update({ status: 'failed' }).eq('id', message.id);
    console.error('[whatsapp] envoi échoué:', err.message);
  }

  res.status(201).json({ message });
});

export default router;
