import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { sendWhatsAppMessage } from '../lib/whatsapp.js';

const router = Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { data, error } = await req.supabase.from('campaigns').select('*').order('created_at', { ascending: false });
  if (error) return res.status(400).json({ error: error.message });
  res.json({ campaigns: data });
});

router.post('/', async (req, res) => {
  const { name, message_template, target_segment, scheduled_at } = req.body;
  if (!name || !message_template) {
    return res.status(400).json({ error: 'name et message_template sont requis.' });
  }
  const { data, error } = await req.supabase
    .from('campaigns')
    .insert({
      owner_id: req.user.id,
      name,
      message_template,
      target_segment,
      scheduled_at,
      status: scheduled_at ? 'scheduled' : 'draft',
    })
    .select()
    .single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json({ campaign: data });
});

// POST /api/campaigns/:id/send — envoi immédiat à tout le segment ciblé.
router.post('/:id/send', async (req, res) => {
  const { data: campaign, error: campError } = await req.supabase
    .from('campaigns')
    .select('*')
    .eq('id', req.params.id)
    .single();
  if (campError || !campaign) return res.status(404).json({ error: 'Campagne introuvable.' });

  let contactsQuery = req.supabase.from('contacts').select('phone_number');
  if (campaign.target_segment) contactsQuery = contactsQuery.eq('segment', campaign.target_segment);
  const { data: contacts, error: contactsError } = await contactsQuery;
  if (contactsError) return res.status(400).json({ error: contactsError.message });

  await req.supabase.from('campaigns').update({ status: 'sending' }).eq('id', campaign.id);

  let sent = 0;
  let failed = 0;
  for (const contact of contacts) {
    try {
      await sendWhatsAppMessage(contact.phone_number, campaign.message_template);
      sent++;
    } catch (err) {
      failed++;
      console.error(`[campaign] échec envoi à ${contact.phone_number}:`, err.message);
    }
  }

  await req.supabase
    .from('campaigns')
    .update({ status: 'sent', sent_at: new Date().toISOString() })
    .eq('id', campaign.id);

  res.json({ sent, failed, total: contacts.length });
});

export default router;
