import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

router.get('/', async (req, res) => {
  const { data, error } = await req.supabase.from('profiles').select('*').eq('id', req.user.id).single();
  if (error) return res.status(400).json({ error: error.message });
  res.json({ profile: data });
});

router.patch('/', async (req, res) => {
  const { full_name, company_name, phone, country } = req.body;
  const { data, error } = await req.supabase
    .from('profiles')
    .update({ full_name, company_name, phone, country })
    .eq('id', req.user.id)
    .select()
    .single();
  if (error) return res.status(400).json({ error: error.message });
  res.json({ profile: data });
});

export default router;
