import { Router } from 'express';
import Stripe from 'stripe';
import { supabaseAdmin } from '../lib/supabase.js';

const router = Router();
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

// IMPORTANT : cette route doit recevoir le corps brut (raw), pas du JSON parsé.
// Voir server.js — express.raw() est appliqué uniquement sur ce chemin.
router.post('/', async (req, res) => {
  if (!stripe) return res.status(500).send('Stripe non configuré.');

  let event;
  try {
    const signature = req.headers['stripe-signature'];
    event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('[stripe] signature invalide:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed':
      case 'invoice.paid': {
        const session = event.data.object;
        const ownerId = session.metadata?.owner_id || session.client_reference_id;
        if (ownerId && supabaseAdmin) {
          await supabaseAdmin.from('payments').insert({
            owner_id: ownerId,
            amount: (session.amount_total ?? session.amount_paid ?? 0) / 100,
            currency: (session.currency || 'eur').toUpperCase(),
            provider: 'stripe',
            provider_ref: session.id,
            status: 'succeeded',
          });
        }
        break;
      }
      case 'customer.subscription.deleted': {
        const sub = event.data.object;
        if (supabaseAdmin) {
          await supabaseAdmin
            .from('subscriptions')
            .update({ status: 'canceled' })
            .eq('payment_provider_ref', sub.id);
        }
        break;
      }
      default:
        break; // événements non traités pour l'instant
    }
    res.json({ received: true });
  } catch (err) {
    console.error('[stripe webhook] erreur de traitement:', err);
    res.status(500).send('Erreur interne.');
  }
});

export default router;
