import { Router } from 'express';
import { supabaseAdmin } from '../lib/supabase.js';

const router = Router();

// GET — Meta vérifie le webhook lors de sa configuration.
router.get('/', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

// POST — réception des messages entrants / accusés de statut.
router.post('/', async (req, res) => {
  // On répond tout de suite : Meta attend un 200 rapide, le traitement se fait après.
  res.sendStatus(200);

  try {
    const entry = req.body?.entry?.[0];
    const change = entry?.changes?.[0]?.value;
    const incoming = change?.messages?.[0];
    if (!incoming || !supabaseAdmin) return;

    const fromNumber = incoming.from;
    const text = incoming.text?.body ?? '[message non textuel]';
    const businessNumber = change?.metadata?.display_phone_number;
    const phoneNumberId = change?.metadata?.phone_number_id;

    // 0. Retrouver À QUEL CLIENT WhaBoost appartient ce numéro WhatsApp
    //    Business (chaque client a connecté le sien via l'Embedded Signup).
    const { data: wConn } = await supabaseAdmin
      .from('whatsapp_connections')
      .select('owner_id')
      .eq('phone_number_id', phoneNumberId)
      .maybeSingle();

    if (!wConn) {
      console.warn(`[whatsapp] Message reçu sur un numéro (${phoneNumberId}) non rattaché à un compte WhaBoost.`);
      return;
    }
    const ownerId = wConn.owner_id;

    // 1. Trouver ou créer le contact, rattaché à ce client précis.
    const { data: existingContact } = await supabaseAdmin
      .from('contacts')
      .select('id, owner_id')
      .eq('phone_number', fromNumber)
      .eq('owner_id', ownerId)
      .limit(1)
      .maybeSingle();

    let contact = existingContact;
    if (!contact) {
      const { data: newContact, error: contactErr } = await supabaseAdmin
        .from('contacts')
        .insert({ owner_id: ownerId, full_name: fromNumber, phone_number: fromNumber })
        .select('id, owner_id')
        .single();
      if (contactErr) {
        console.error('[whatsapp] création contact échouée:', contactErr.message);
        return;
      }
      contact = newContact;
    }

    // 2. Trouver ou créer la conversation.
    const { data: existingConv } = await supabaseAdmin
      .from('conversations')
      .select('id')
      .eq('contact_id', contact.id)
      .eq('status', 'open')
      .limit(1)
      .maybeSingle();

    let conversationId = existingConv?.id;
    if (!conversationId) {
      const { data: newConv } = await supabaseAdmin
        .from('conversations')
        .insert({ owner_id: contact.owner_id, contact_id: contact.id, whatsapp_business_number: businessNumber })
        .select('id')
        .single();
      conversationId = newConv?.id;
    }

    // 3. Enregistrer le message + mettre à jour last_message_at.
    await supabaseAdmin.from('messages').insert({
      conversation_id: conversationId,
      direction: 'inbound',
      sender_type: 'contact',
      content: text,
      whatsapp_message_id: incoming.id,
      status: 'delivered',
    });
    await supabaseAdmin
      .from('conversations')
      .update({ last_message_at: new Date().toISOString() })
      .eq('id', conversationId);
  } catch (err) {
    console.error('[whatsapp webhook] erreur de traitement:', err);
  }
});

export default router;
