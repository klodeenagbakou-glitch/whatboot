import { Router } from 'express';
import { supabaseAdmin } from '../lib/supabase.js';

const router = Router();

// GET — Meta vérifie le webhook lors de sa configuration.
router.get('/', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

// POST — réception des messages entrants / accusés de statut.
router.post('/', async (req, res) => {
  // On répond tout de suite : Meta attend un 200 rapide, le traitement se fait après.
  res.sendStatus(200);

  try {
    const entry = req.body?.entry?.[0];
    const change = entry?.changes?.[0]?.value;
    const incoming = change?.messages?.[0];
    if (!incoming || !supabaseAdmin) return;

    const fromNumber = incoming.from;
    const text = incoming.text?.body ?? '[message non textuel]';
    const businessNumber = change?.metadata?.display_phone_number;

    // 1. Trouver ou créer le contact (multi-tenant : ownership à préciser
    //    ensuite, ici on rattache au premier compte trouvé pour ce numéro
    //    business — à affiner quand plusieurs clients partageront le backend).
    const { data: existingContact } = await supabaseAdmin
      .from('contacts')
      .select('id, owner_id')
      .eq('phone_number', fromNumber)
      .limit(1)
      .maybeSingle();

    let contact = existingContact;
    if (!contact) {
      // TODO: déterminer owner_id à partir du businessNumber une fois
      // plusieurs comptes WhaBoost actifs (table de mapping numéro -> owner_id).
      console.warn(`[whatsapp] Nouveau contact ${fromNumber} sans owner_id déterminé — à router.`);
      return;
    }

    // 2. Trouver ou créer la conversation.
    const { data: existingConv } = await supabaseAdmin
      .from('conversations')
      .select('id')
      .eq('contact_id', contact.id)
      .eq('status', 'open')
      .limit(1)
      .maybeSingle();

    let conversationId = existingConv?.id;
    if (!conversationId) {
      const { data: newConv } = await supabaseAdmin
        .from('conversations')
        .insert({ owner_id: contact.owner_id, contact_id: contact.id, whatsapp_business_number: businessNumber })
        .select('id')
        .single();
      conversationId = newConv?.id;
    }

    // 3. Enregistrer le message + mettre à jour last_message_at.
    await supabaseAdmin.from('messages').insert({
      conversation_id: conversationId,
      direction: 'inbound',
      sender_type: 'contact',
      content: text,
      whatsapp_message_id: incoming.id,
      status: 'delivered',
    });
    await supabaseAdmin
      .from('conversations')
      .update({ last_message_at: new Date().toISOString() })
      .eq('id', conversationId);
  } catch (err) {
    console.error('[whatsapp webhook] erreur de traitement:', err);
  }
});

export default router;
