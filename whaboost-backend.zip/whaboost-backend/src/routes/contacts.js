import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

// GET /api/contacts?search=&segment=
router.get('/', async (req, res) => {
  const { search, segment } = req.query;
  let query = req.supabase.from('contacts').select('*').order('created_at', { ascending: false });

  if (search) query = query.or(`full_name.ilike.%${search}%,phone_number.ilike.%${search}%`);
  if (segment) query = query.eq('segment', segment);

  const { data, error } = await query;
  if (error) return res.status(400).json({ error: error.message });
  res.json({ contacts: data });
});

// POST /api/contacts
router.post('/', async (req, res) => {
  const { full_name, phone_number, email, tags, segment, source, notes } = req.body;
  if (!full_name || !phone_number) {
    return res.status(400).json({ error: 'full_name et phone_number sont requis.' });
  }
  const { data, error } = await req.supabase
    .from('contacts')
    .insert({ owner_id: req.user.id, full_name, phone_number, email, tags, segment, source, notes })
    .select()
    .single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json({ contact: data });
});

// PATCH /api/contacts/:id
router.patch('/:id', async (req, res) => {
  const { data, error } = await req.supabase
    .from('contacts')
    .update(req.body)
    .eq('id', req.params.id)
    .select()
    .single();
  if (error) return res.status(400).json({ error: error.message });
  res.json({ contact: data });
});

// DELETE /api/contacts/:id
router.delete('/:id', async (req, res) => {
  const { error } = await req.supabase.from('contacts').delete().eq('id', req.params.id);
  if (error) return res.status(400).json({ error: error.message });
  res.status(204).end();
});

// POST /api/contacts/import  { rows: [{full_name, phone_number, email}, ...] }
// Sert à l'import Excel/CSV fait côté frontend (parsing avec SheetJS/Papaparse).
router.post('/import', async (req, res) => {
  const { rows } = req.body;
  if (!Array.isArray(rows) || rows.length === 0) {
    return res.status(400).json({ error: 'rows doit être un tableau non vide.' });
  }
  const payload = rows
    .filter((r) => r.full_name && r.phone_number)
    .map((r) => ({ ...r, owner_id: req.user.id, source: 'import' }));

  const { data, error } = await req.supabase.from('contacts').insert(payload).select();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json({ imported: data.length, contacts: data });
});

export default router;
