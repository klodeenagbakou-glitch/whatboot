import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const GRAPH_VERSION = 'v20.0';

// GET /api/whatsapp/status — le dashboard l'appelle pour savoir si le
// client a déjà connecté un numéro WhatsApp.
router.get('/status', async (req, res) => {
  const { data, error } = await req.supabase
    .from('whatsapp_connections')
    .select('business_phone_number, display_name, status, connected_at')
    .maybeSingle();
  if (error) return res.status(400).json({ error: error.message });
  res.json({ connection: data || null });
});

// POST /api/whatsapp/connect   { code, waba_id, phone_number_id, business_phone_number }
// Reçoit les informations renvoyées par la fenêtre "Embedded Signup" de Meta
// une fois que le client a choisi son numéro WhatsApp.
router.post('/connect', async (req, res) => {
  const { code, waba_id, phone_number_id, business_phone_number, display_name } = req.body;
  if (!code || !waba_id || !phone_number_id) {
    return res.status(400).json({ error: 'code, waba_id et phone_number_id sont requis.' });
  }

  const appId = process.env.META_APP_ID;
  const appSecret = process.env.META_APP_SECRET;
  const systemToken = process.env.WHATSAPP_SYSTEM_TOKEN;
  if (!appId || !appSecret || !systemToken) {
    return res.status(500).json({ error: "WhatsApp n'est pas encore configuré côté serveur (META_APP_ID / META_APP_SECRET / WHATSAPP_SYSTEM_TOKEN manquants)." });
  }

  try {
    // 1. Échange le "code" de l'Embedded Signup contre un accès temporaire —
    //    cette étape finalise le partage du numéro WhatsApp du client avec
    //    notre app Meta (WhaBoost).
    const tokenRes = await fetch(
      `https://graph.facebook.com/${GRAPH_VERSION}/oauth/access_token?client_id=${appId}&client_secret=${appSecret}&code=${encodeURIComponent(code)}`
    );
    const tokenData = await tokenRes.json();
    if (!tokenRes.ok) {
      throw new Error(tokenData?.error?.message || "Échange du code d'autorisation Meta échoué.");
    }

    // 2. Abonne notre app aux évènements (messages entrants) de ce compte
    //    WhatsApp Business — sans ça, on ne reçoit jamais les réponses des clients.
    const subRes = await fetch(`https://graph.facebook.com/${GRAPH_VERSION}/${waba_id}/subscribed_apps`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${systemToken}` },
    });
    const subData = await subRes.json();
    if (!subRes.ok) {
      throw new Error(subData?.error?.message || "Abonnement au compte WhatsApp Business échoué.");
    }

    // 3. Enregistre la connexion pour ce client (une ligne par entreprise).
    const { data, error } = await req.supabase
      .from('whatsapp_connections')
      .upsert(
        {
          owner_id: req.user.id,
          waba_id,
          phone_number_id,
          business_phone_number,
          display_name,
          status: 'connected',
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'owner_id' }
      )
      .select()
      .single();
    if (error) throw new Error(error.message);

    res.status(201).json({ connection: data });
  } catch (err) {
    console.error('[whatsapp connect] erreur:', err.message);
    res.status(400).json({ error: err.message });
  }
});

// DELETE /api/whatsapp/disconnect
router.delete('/disconnect', async (req, res) => {
  const { error } = await req.supabase
    .from('whatsapp_connections')
    .delete()
    .eq('owner_id', req.user.id);
  if (error) return res.status(400).json({ error: error.message });
  res.status(204).send();
});

export default router;
