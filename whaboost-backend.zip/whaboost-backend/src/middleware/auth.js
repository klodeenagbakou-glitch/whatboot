import { supabaseForUser } from '../lib/supabase.js';

/**
 * Vérifie le token Supabase envoyé par le frontend et attache
 * req.supabase (client scopé à l'utilisateur) + req.user.
 */
export async function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Authentification requise (token manquant).' });
  }

  const supabase = supabaseForUser(token);
  const { data, error } = await supabase.auth.getUser(token);

  if (error || !data?.user) {
    return res.status(401).json({ error: 'Session invalide ou expirée.' });
  }

  req.supabase = supabase;
  req.user = data.user;
  next();
}
