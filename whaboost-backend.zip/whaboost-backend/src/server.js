import 'dotenv/config';
import express from 'express';
import cors from 'cors';

import contactsRouter from './routes/contacts.js';
import conversationsRouter from './routes/conversations.js';
import campaignsRouter from './routes/campaigns.js';
import profileRouter from './routes/profile.js';
import whatsappWebhookRouter from './routes/whatsappWebhook.js';
import stripeWebhookRouter from './routes/stripeWebhook.js';

const app = express();

app.use(cors({ origin: process.env.FRONTEND_ORIGIN || '*' }));

// Le webhook Stripe a besoin du corps brut pour vérifier la signature :
// on l'enregistre AVANT express.json() global.
app.use('/webhooks/stripe', express.raw({ type: 'application/json' }), stripeWebhookRouter);

app.use(express.json());

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'whaboost-backend' }));

app.use('/webhooks/whatsapp', whatsappWebhookRouter);

app.use('/api/contacts', contactsRouter);
app.use('/api/conversations', conversationsRouter);
app.use('/api/campaigns', campaignsRouter);
app.use('/api/profile', profileRouter);

app.use((req, res) => res.status(404).json({ error: 'Route inconnue.' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Erreur serveur.' });
});

const PORT = process.env.PORT || 10000;
app.listen(PORT, () => console.log(`WhaBoost backend démarré sur le port ${PORT}`));
